const { postDocument, queryDocument } = require("../mysql");
const { deleteImage } = require("./common");

async function postSuppier(req, res, next) {
  try {
    req.body.profile = req.file.filename;
    const sql = "INSERT INTO supplier SET ";
    const result = await postDocument(sql, req.body);
    if (!result.insertId) throw { message: "Opps! unable to add" };
    res.send({ message: "Added successfully" });
  } catch (error) {
    if (req.file.filename) deleteImage(req.file.filename);
    next(error);
  }
}

async function getSupplier(req, res, next) {
  try {
    if (req.query.id) {
      const sql = `SELECT * FROM supplier WHERE id = '${req.query.id}'`;
      const supplier = await queryDocument(sql);
      const page = parseInt(req.query.page || 0);
      const limit = (page + 1) * 51;

      const allOrdersql = `SELECT id FROM purchased WHERE supplier_id = ${req.query.id}`;
      const allOrder = await queryDocument(allOrdersql);

      const ordersSql = `SELECT p.*, users.name FROM purchased p INNER JOIN switchcafebd_user_info.users ON users.id = p.purchased_by WHERE supplier_id = ${
        req.query.id
      } ORDER BY p.date DESC LIMIT ${page * 50}, ${limit - 1}`;
      const orders = await queryDocument(ordersSql);
      supplier[0].orders = orders;
      res.send({ count: allOrder.length, data: supplier[0] });
    } else {
      let sql = "SELECT * FROM supplier ";
      if (req.query.type) {
        sql = "SELECT *, 'supplier' as type FROM supplier ";
      }
      const result = await queryDocument(sql);
      res.send(result);
    }
  } catch (error) {
    next(error);
  }
}

async function updateSupplier(req, res, next) {
  try {
    const id = req.body.id;
    let existedImg = req.body.existedImg;
    delete req.body.id;
    delete req.body.existedImg;
    if (existedImg) {
      req.body.profile = req.file.filename;
    }
    const sql = "UPDATE supplier SET ";
    const condition = ` WHERE id='${id}'`;
    const result = await postDocument(sql, req.body, condition);
    if (!result.affectedRows) throw { message: "Opps! unable to update" };
    if (existedImg) deleteImage(existedImg);
    res.send({ message: "update successfully" });
  } catch (error) {
    if (req.file.filename) deleteImage(req.file.filename);
    next(error);
  }
}

async function deleteSupplier(req, res, next) {
  try {
    const sql = `DELETE FROM supplier WHERE id = '${req.query.id}'`;
    const result = await queryDocument(sql);
    if (!result.affectedRows) throw { message: "Opps! unable to delete" };
    if (req.query.profile) deleteImage(req.query.profile);
    res.send({ message: "Deleted successfully" });
  } catch (error) {
    next(error);
  }
}

module.exports = {
  postSuppier,
  getSupplier,
  updateSupplier,
  deleteSupplier,
};

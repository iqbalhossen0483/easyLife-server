const express = require("express");
const { queryDocument, postDocument } = require("../mysql");
const {
  updateStockReport,
  updateCashReport,
  insertCashReport,
} = require("../services/order");
const multer = require("../middleWares/multer");
const purchaseRouter = express.Router();

purchaseRouter.post("/", multer.array("files"), async (req, res, next) => {
  try {
    const {
      supplierId,
      totalPurchased,
      giveAmount,
      debtAmount,
      userId,
      payment_info,
    } = req.body;
    const product = JSON.parse(req.body.product);

    //insert or update product purchase information;
    const purchaseSql = "INSERT INTO purchased SET ";
    let files = "";
    if (req.files.length) {
      req.files.forEach((file) => {
        if (files) files += "," + file.filename;
        else files += file.filename;
      });
    }
    const docs = {
      supplier_id: supplierId,
      total_amount: totalPurchased,
      payment: giveAmount,
      due: debtAmount,
      purchased_by: userId,
      payment_info,
      files,
    };

    const purchase = await postDocument(purchaseSql, docs);
    // till;

    //update supplier;
    const supplierSql = `UPDATE supplier SET totalPurchased = totalPurchased + ${totalPurchased}, giveAmount = giveAmount + ${giveAmount}, debtAmount= debtAmount + ${debtAmount} WHERE id = '${supplierId}'`;
    await queryDocument(supplierSql);

    //update user profile;
    const userSql = `UPDATE switchcafebd_user_info.users SET haveMoney = haveMoney - ${giveAmount} WHERE id = '${userId}'`;
    await queryDocument(userSql);

    //insert a transition history;
    if (parseInt(giveAmount || 0) > 0) {
      const transsitionSql = "INSERT INTO transaction SET ";
      const transitionData = {
        fromUser: userId,
        toUser: supplierId,
        purpose: "Purchase Product",
        amount: giveAmount,
      };
      await postDocument(transsitionSql, transitionData);
    }

    //update cash reports;
    //update daily cash report;
    const date = new Date();
    const data = { purchased: giveAmount };
    await updateCashReport("daily_cash_report", data, date, "date", true);

    //update monthly cash report;
    await updateCashReport("monthly_cash_report", data, date, "month", true);

    //update yearly cash report;
    await updateCashReport("yearly_cash_report", data, date, "year", true);

    //update product information;
    for (item of product) {
      const { productId, purchased } = item;
      //update product stock;
      const productSql = `UPDATE products SET stock = stock + ${purchased}, purchased= purchased + ${purchased} WHERE id = '${productId}'`;
      await queryDocument(productSql);

      //add product to purchase list;
      const productsql = "INSERT INTO purchased_product SET ";
      const productsDocs = {
        product_id: productId,
        qty: purchased,
        purchase_id: purchase.insertId,
      };
      await postDocument(productsql, productsDocs);

      //update product report;
      //update daily stock report;
      await updateStockReport("daily_stock_report", item, date, "daily", true);

      //update monthly stock report;
      await updateStockReport(
        "monthly_stock_report",
        item,
        date,
        "month",
        true
      );

      //update yearly stock report;
      await updateStockReport("yearly_stock_report", item, date, "year", true);
    }
    res.send({ message: "Product purchase successfully added" });
  } catch (error) {
    next(error);
  }
});

purchaseRouter.get("/", async (req, res, next) => {
  try {
    if (req.query.id) {
      const sql = `SELECT purchased.*, s.name, s.address FROM purchased INNER JOIN supplier s ON s.id = purchased.supplier_id WHERE purchased.id = '${req.query.id}'`;
      const purchased = await queryDocument(sql);
      const productsql = `SELECT pp.*, p.shortName as name, p.name as full_name FROM purchased_product pp INNER JOIN products p ON pp.product_id = p.id WHERE pp.purchase_id = '${purchased[0].id}'`;
      const products = await queryDocument(productsql);
      purchased[0].products = products;

      const collectionsql = `SELECT pc.*, users.name FROM purchased_collection pc INNER JOIN switchcafebd_user_info.users ON users.id = pc.senderId WHERE pc.orderId = '${purchased[0].id}'`;
      const collection = await queryDocument(collectionsql);
      purchased[0].collections = collection;
      res.send(purchased[0]);
    } else {
      const sql = "SELECT * FROM purchased";
      const result = await queryDocument(sql);
      res.send(result);
    }
  } catch (error) {
    next(error);
  }
});

purchaseRouter.put(
  "/collection",
  multer.array("files"),
  async (req, res, next) => {
    try {
      const { payment, due, discount, supplierId, sent_by } = req.body;
      const collection = JSON.parse(req.body.collection);

      let files = "";
      if (req.body.files) {
        files = req.body.files;
      }
      if (req.files.length) {
        req.files.forEach((file) => {
          if (files) files += "," + file.filename;
          else files += file.filename;
        });
      }

      //update order info;
      const sql = `UPDATE purchased SET payment=payment + ${payment}, due=${due},discount=${discount}, files = '${files}' WHERE id = '${req.query.id}'`;
      const result = await queryDocument(sql);
      if (!result.affectedRows)
        throw { message: "Unable to received collection" };

      //insert a collection list;
      const collectionSql = "INSERT INTO purchased_collection SET ";
      await postDocument(collectionSql, collection);

      //update the suplier;
      const shopSql = `UPDATE supplier SET giveAmount = giveAmount + ${payment},discount= discount + ${discount}, 	debtAmount= 	debtAmount - ${payment} - ${discount} WHERE id = '${supplierId}'`;
      await queryDocument(shopSql);

      //update collection info into the user profile;
      const deliverSql = `UPDATE switchcafebd_user_info.users SET haveMoney = haveMoney - ${payment} WHERE id = ${sent_by}`;
      await queryDocument(deliverSql);

      //update cash report ;
      const isExistTodaySql = `SELECT id FROM daily_cash_report WHERE DATE(date) = CURDATE()`;
      const isExistToday = await queryDocument(isExistTodaySql);

      if (isExistToday.length) {
        let updateReportSql = `UPDATE daily_cash_report SET closing = closing - ${payment}, purchase = purchase + ${payment} WHERE id = '${isExistToday[0].id}'`;
        await queryDocument(updateReportSql);

        const date = new Date();
        const month = date.toLocaleString("en-us", { month: "long" });
        const year = date.getFullYear();
        const updatemonthlySql = `UPDATE monthly_cash_report SET closing = closing + ${payment},  purchase = purchase + ${payment}  WHERE month = '${month}'`;
        await queryDocument(updatemonthlySql);
        const updateyearlySql = `UPDATE yearly_cash_report SET closing = closing + ${payment},  purchase = purchase + ${payment} WHERE year = '${year}'`;
        await queryDocument(updateyearlySql);
      } else {
        const date = new Date();
        await insertCashReport(
          "daily_cash_report",
          date,
          "date",
          payment,
          discount
        );
        await insertCashReport(
          "monthly_cash_report",
          date,
          "month",
          payment,
          discount
        );
        await insertCashReport(
          "yearly_cash_report",
          date,
          "year",
          payment,
          discount
        );
      }

      res.send({ message: "Collection send successfully" });
    } catch (error) {
      next(error);
    }
  }
);

module.exports = purchaseRouter;

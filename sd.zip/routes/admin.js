const express = require("express");
const {
  getData,
  sendNotification,
  transations,
  getPendingCommission,
  achieveCommission,
  updateSiteinfo,
  siteinfo,
  postBranch,
  getBranch,
  deleteBranch,
  updateBranch
} = require("../services/deshboard");
const adminRouter = express.Router();

adminRouter.get("/", getData);
adminRouter.get("/notification", sendNotification);
adminRouter.get("/transitions", transations);
adminRouter.get("/commission", getPendingCommission);
adminRouter.post("/commission", achieveCommission);
adminRouter.put("/updateSiteinfo", updateSiteinfo);
adminRouter.get("/siteInfo", siteinfo);
adminRouter.post("/branch", postBranch);
adminRouter.get("/branch", getBranch);
adminRouter.delete("/branch", deleteBranch);
adminRouter.put("/branch", updateBranch);

module.exports = adminRouter;
